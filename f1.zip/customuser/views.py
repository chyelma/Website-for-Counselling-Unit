from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import CustomUser
from django.contrib.auth.models import User
from django.http import HttpResponse
from .models import CustomUser

# Create your views here.
